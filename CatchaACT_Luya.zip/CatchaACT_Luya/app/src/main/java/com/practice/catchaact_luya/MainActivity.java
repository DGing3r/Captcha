package com.practice.catchaact_luya;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.widget.AppCompatButton;
import java.util.Random;
import android.content.Intent;
import android.widget.Toast;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    TextView code;
    TextInputEditText input;
    AppCompatButton bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FindViews();
        Coderunner();
        bt.setOnClickListener(view -> Eventhandler());
    }

    private void Eventhandler() {
            if (code.getText().toString().equals(Objects.requireNonNull(input.getText()).toString())){
                Toast.makeText(getApplicationContext(), "WELCOME DEAR FELLOW!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, NewAct1.class);
                startActivity(intent);
            }
            else{
                code.setText(getRandomString(7));
                Toast.makeText(getApplicationContext(),
                        "Oops! That's the wrong code!", Toast.LENGTH_SHORT).show();
            }
        }

    private void FindViews() {
        code = findViewById(R.id.textView3);
        bt = findViewById(R.id.bt);
        input = findViewById(R.id.input);
    }

    private void Coderunner() {
        Toast.makeText(getApplicationContext(),
                "PLEASE CLARIFY THAT YOU ARE HUMAN", Toast.LENGTH_LONG).show();
        code.setText(getRandomString(7));
    }

    public String getRandomString(int size) {
        final String RandChars = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
        Random rand = new Random();
        StringBuilder ret = new StringBuilder();
        for (int i = 0; i < size; ++i) {
            ret.append(RandChars.charAt(rand.nextInt(RandChars.length())));
        }
        return ret.toString();
    }
}